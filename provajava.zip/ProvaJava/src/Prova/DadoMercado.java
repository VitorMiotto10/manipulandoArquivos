package Prova;

public class DadoMercado {

	private String ID_PRECO;
	private Integer NU_PRAZO_DIAS_CORRIDOS;
	private Double VL_PRECO;
	
	
	public String getID_PRECO() {
		return ID_PRECO;
	}
	public void setID_PRECO(String iD_PRECO) {
		ID_PRECO = iD_PRECO;
	}
	public Integer getNU_PRAZO_DIAS_CORRIDOS() {
		return NU_PRAZO_DIAS_CORRIDOS;
	}
	public void setNU_PRAZO_DIAS_CORRIDOS(Integer nU_PRAZO_DIAS_CORRIDOS) {
		NU_PRAZO_DIAS_CORRIDOS = nU_PRAZO_DIAS_CORRIDOS;
	}
	public Double getVL_PRECO() {
		return VL_PRECO;
	}
	public void setVL_PRECO(Double vL_PRECO) {
		VL_PRECO = vL_PRECO;
	}
	@Override
	public String toString() {
		return "DadoMercado [ID_PRECO=" + ID_PRECO + ", NU_PRAZO_DIAS_CORRIDOS=" + NU_PRAZO_DIAS_CORRIDOS
				+ ", VL_PRECO=" + VL_PRECO + "]";
	}
	
	
	
	
}
