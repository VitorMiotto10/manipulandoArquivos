package Prova;

import java.time.LocalDate;

public class Operacao {

	private String ID_PRECO;
	private LocalDate DT_INICIO;
	private LocalDate DT_FIM;
	private String CD_OPERACOES;
	private String NM_EMPRESA;
	private String NM_MESA;
	private String NM_ESTRATEGIA;
	private String NM_CENTRALIZADOR;
	private String NM_GESTOR;
	private String NM_SUBGESTOR;
	private String NM_SUBPRODUTO;
	private String NM_CARACTERISTICA;
	private String CD_ATIVO_OBJETO;
	private Double QUANTIDADE;

	public String getID_PRECO() {
		return ID_PRECO;
	}

	public void setID_PRECO(String iD_PRECO) {
		ID_PRECO = iD_PRECO;
	}

	public LocalDate getDT_INICIO() {
		return DT_INICIO;
	}

	public void setDT_INICIO(LocalDate dT_INICIO) {
		DT_INICIO = dT_INICIO;
	}

	public LocalDate getDT_FIM() {
		return DT_FIM;
	}

	public void setDT_FIM(LocalDate dT_FIM) {
		DT_FIM = dT_FIM;
	}

	public String getCD_OPERACOES() {
		return CD_OPERACOES;
	}

	public void setCD_OPERACOES(String cD_OPERACOES) {
		CD_OPERACOES = cD_OPERACOES;
	}

	public String getNM_EMPRESA() {
		return NM_EMPRESA;
	}

	public void setNM_EMPRESA(String nM_EMPRESA) {
		NM_EMPRESA = nM_EMPRESA;
	}

	public String getNM_MESA() {
		return NM_MESA;
	}

	public void setNM_MESA(String nM_MESA) {
		NM_MESA = nM_MESA;
	}

	public String getNM_ESTRATEGIA() {
		return NM_ESTRATEGIA;
	}

	public void setNM_ESTRATEGIA(String nM_ESTRATEGIA) {
		NM_ESTRATEGIA = nM_ESTRATEGIA;
	}

	public String getNM_CENTRALIZADOR() {
		return NM_CENTRALIZADOR;
	}

	public void setNM_CENTRALIZADOR(String nM_CENTRALIZADOR) {
		NM_CENTRALIZADOR = nM_CENTRALIZADOR;
	}

	public String getNM_GESTOR() {
		return NM_GESTOR;
	}

	public void setNM_GESTOR(String nM_GESTOR) {
		NM_GESTOR = nM_GESTOR;
	}

	public String getNM_SUBGESTOR() {
		return NM_SUBGESTOR;
	}

	public void setNM_SUBGESTOR(String nM_SUBGESTOR) {
		NM_SUBGESTOR = nM_SUBGESTOR;
	}

	public String getNM_SUBPRODUTO() {
		return NM_SUBPRODUTO;
	}

	public void setNM_SUBPRODUTO(String nM_SUBPRODUTO) {
		NM_SUBPRODUTO = nM_SUBPRODUTO;
	}

	public String getNM_CARACTERISTICA() {
		return NM_CARACTERISTICA;
	}

	public void setNM_CARACTERISTICA(String nM_CARACTERISTICA) {
		NM_CARACTERISTICA = nM_CARACTERISTICA;
	}

	public String getCD_ATIVO_OBJETO() {
		return CD_ATIVO_OBJETO;
	}

	public void setCD_ATIVO_OBJETO(String cD_ATIVO_OBJETO) {
		CD_ATIVO_OBJETO = cD_ATIVO_OBJETO;
	}

	public Double getQUANTIDADE() {
		return QUANTIDADE;
	}

	public void setQUANTIDADE(Double qUANTIDADE) {
		QUANTIDADE = qUANTIDADE;
	}

	@Override
	public String toString() {
		return "Operacao [ID_PRECO=" + ID_PRECO + ", DT_INICIO=" + DT_INICIO + ", DT_FIM=" + DT_FIM + ", CD_OPERACOES="
				+ CD_OPERACOES + ", NM_EMPRESA=" + NM_EMPRESA + ", NM_MESA=" + NM_MESA + ", NM_ESTRATEGIA="
				+ NM_ESTRATEGIA + ", NM_CENTRALIZADOR=" + NM_CENTRALIZADOR + ", NM_GESTOR=" + NM_GESTOR
				+ ", NM_SUBGESTOR=" + NM_SUBGESTOR + ", NM_SUBPRODUTO=" + NM_SUBPRODUTO + ", NM_CARACTERISTICA="
				+ NM_CARACTERISTICA + ", CD_ATIVO_OBJETO=" + CD_ATIVO_OBJETO + ", QUANTIDADE=" + QUANTIDADE + "]";
	}

	
	
}
