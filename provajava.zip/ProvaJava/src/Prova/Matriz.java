package Prova;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.text.DateFormatter;

import javafx.util.converter.LocalDateTimeStringConverter;


public class Matriz {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Matriz obj = new Matriz();
		obj.construirOperacoes();		
		obj.construirDadosMercado();
		obj.construirResultados();
		
//		System.out.println(obj.dadosMercado.size());
//		System.out.println(obj.operacoes.size());
		
		for (Operacao operacao : obj.operacoes) {
			
			for (DadoMercado dadoMercado : obj.dadosMercado) {
				if (operacao.getID_PRECO().equals(dadoMercado.getID_PRECO())) {
					Double resultado = operacao.getQUANTIDADE() * dadoMercado.getVL_PRECO();
					System.out.println("DadoMercado: " + dadoMercado.getID_PRECO() + 
							"Operacao: " + operacao.getID_PRECO() +
							"Resultado: " + resultado );							
					
				}
			}
		}
		
		for (Operacao operacao : obj.operacoes) {
			for (DadoMercado dadoMercado : obj.dadosMercado) {
				
				 
						LocalDate dtfim = LocalDate.now();
				        
				        // Cria um Objeto LocalDate com a data 26/09/2020.
				        LocalDate dtinicio = LocalDate.of(2020, Month.SEPTEMBER, 26);
				        
				        // Calcula a diferen�a de dias entre as duas datas
				        long diferencaEmDias = ChronoUnit.DAYS.between(dtfim, dtinicio);
				        // Calcula a diferen�a de meses entre as duas datas
				        
				        
				        // Exibe a diferen�a em dias entre as datas
				        System.out.println("Diferen�a em dias entre " + dtfim + " e " + dtinicio + " = " + diferencaEmDias + " dias.");
				        
				
				if (operacao.getID_PRECO().equals(dadoMercado.getID_PRECO()));{
					
				}
			}
		}
		
		
		
		//obj.gerarCsvResultados(resultados);

	}
	//private List<Resultado> resultados;
	
	public void construirResultados () {
		
		/*if (((DadoMercado) dadosMercado).getID_PRECO() != null && ((DadoMercado) dadosMercado).getID_PRECO().isEmpty()) {
			this.dadosMercado.setID_PRECO(0);*/
		}
		
		
	
	
	private List<DadoMercado> dadosMercado;
	
	public void construirDadosMercado () {
	
	dadosMercado = new ArrayList<DadoMercado>(); 
	  
    String arquivoCSV = "C:\\Users\\re038074\\Desktop\\Prova Java\\Prova C#\\DadosMercado.csv";
    BufferedReader br = null;
    String linha = "";
    String csvDivisor = ";";
    int i = 0;
    try {

        br = new BufferedReader(new FileReader(arquivoCSV));
        while ((linha = br.readLine()) != null) {
        	
        	if (i == 0) {
        		i++;
        		continue;
        	}
        	
        	DadoMercado dadoMercado = new DadoMercado();
        	
            String[] linhaArray = linha.split(csvDivisor);
            dadoMercado.setID_PRECO(linhaArray[0]);
            Integer integer = Integer.parseInt(linhaArray[1]);
            dadoMercado.setNU_PRAZO_DIAS_CORRIDOS(integer);
            dadoMercado.setVL_PRECO(DecimalFormat.getNumberInstance().parse(linhaArray[2]).doubleValue());
                        
            
            
            dadosMercado.add(dadoMercado);
            
            
    }

    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
        if (br != null) {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
      }
    }  

	private List<Operacao> operacoes;
	
	  public void construirOperacoes() throws ParseException {
		  
		operacoes = new ArrayList<Operacao>(); 
		  
	    String arquivoCSV = "C:\\Users\\re038074\\Desktop\\Prova Java\\Prova C#\\Operacoes.csv";
	    BufferedReader br = null;
	    String linha = "";
	    String csvDivisor = ";";
	    try {

	        br = new BufferedReader(new FileReader(arquivoCSV));
	        br.readLine();
	        while ((linha = br.readLine()) != null) {

	        	Operacao operacao = new Operacao();
	        	LocalDate data = null;
	        	LocalDate data1 = null;
	        	DateTimeFormatter formato = null; 
	        	
	            String[] linhaArray = linha.split(csvDivisor);
	            operacao.setCD_OPERACOES(linhaArray[0]);
	            formato = DateTimeFormatter.ofPattern( "dd/MM/yyyy" );
	            data = LocalDate.parse(linhaArray[1]);	            			            			            
	            operacao.setDT_INICIO(data);
	            data1 = LocalDate.parse(linhaArray[2]);
	            operacao.setDT_FIM(data1);
	            operacao.setNM_EMPRESA(linhaArray[3]);
	            operacao.setNM_MESA(linhaArray[4]);
	            operacao.setNM_ESTRATEGIA(linhaArray[5]);
	            operacao.setNM_CENTRALIZADOR(linhaArray[6]);
	            operacao.setNM_GESTOR(linhaArray[7]);
	            operacao.setNM_SUBGESTOR(linhaArray[8]);
	            operacao.setNM_SUBPRODUTO(linhaArray[9]);
	            operacao.setNM_CARACTERISTICA(linhaArray[10]);
	            operacao.setCD_ATIVO_OBJETO(linhaArray[11]);
	            operacao.setQUANTIDADE(DecimalFormat.getNumberInstance().parse(linhaArray[12]).doubleValue());
	            operacao.setID_PRECO(linhaArray[13]);
	            
//	            SimpleDateFormat formato = new SimpleDateFormat( "dd/MM/yyyy" ); Date data = formato.parse
	            
	            operacoes.add(operacao);
	            
	    }

	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        if (br != null) {
	            try {
	                br.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	  }

	}
 