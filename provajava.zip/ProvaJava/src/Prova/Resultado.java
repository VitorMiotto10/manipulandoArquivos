package Prova;

public class Resultado {
	
	private String NM_RESULTADO;
	private Double Resultado;
	private Integer ID_PRECO;
	
	
	
	
	public String getNM_RESULTADO() {
		return NM_RESULTADO;
	}
	public void setNM_RESULTADO(String nM_RESULTADO) {
		NM_RESULTADO = nM_RESULTADO;
	}
	public Double getResultado() {
		return Resultado;
	}
	public void setResultado(Double resultado) {
		Resultado = resultado;
	}
	public Integer getID_PRECO() {
		return ID_PRECO;
	}
	public void setID_PRECO(Integer iD_PRECO) {
		ID_PRECO = iD_PRECO;
	}
	
	
	

}
